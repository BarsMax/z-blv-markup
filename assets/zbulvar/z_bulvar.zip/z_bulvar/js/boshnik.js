(function ($) { 

var past = $('.past'); // прошедшая акция
/**
 * При клике по прошедшей акции ничего не должно происходить
 */

// past.on('click', function(){
// 	return false;
// })



/**
 **************** MENU ANIMATION ******************
 */
var menu_item = $('.menu_item'),
    menu_box = $('.menu_box'),
    menu_show = $('.menu_box_show'),
    menu_list = $('.menu_list')

/**
 * Add class animation
 */
menu_box.add(menu_list).addClass('animated zero-hack');

/**
 * Click menu_item
 * прячем с анимацией меню
 * показываем список текущего меню 
 */

menu_item.on('click', function(){
	menu_box.removeClass('fadeInLeftBig').addClass('fadeOutLeftBig');
	menu_list.removeClass('fadeOutRightBig hide').addClass('fadeInRightBig');
})

/**
 * Click menu_show
 * прячем с анимацией список меню
 * показываем меню 
 */

var home_h1 = $('.home_h1'),
    hone_h1_text = home_h1.text();

menu_show.on('click', function(e){
	e.preventDefault();
	menu_list.removeClass('fadeInRightBig').addClass('fadeOutRightBig');
	menu_box.removeClass('fadeOutLeftBig').addClass('fadeInLeftBig');
    home_h1.text(hone_h1_text)
	
})



})(jQuery);
