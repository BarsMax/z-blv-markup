/**
 *
 * Sasha Boshnik
 * Boshnik.com.ua
 * v0.24--03.11.2014
 */
(function ($) { 
/**
 * add class full-menu = active-menu + scrollSpy + anchor + anchor-spy
 */
$('.full-menu').addClass('active-menu scrollSpy anchor anchor-spy').removeClass('full-menu');
/**
 * Переменные
 */
var topBody = $(".top-body"),
    htmlBody = $("html, body"),
    body = $("body"),
    thisPage = window.location.href,
    scroller,
    arrModClass = ['size','dec','hov','act','dis'],
    resizeArr = ["320", "481", "641", "769", "961", "1025", "1281", "1367", "1681", "2000"],
    parentBo = $('[data-child]'),
    nodeBo = $('[data-node]'),
    parent = $('.parent'),
    scrollSpy = $('.scrollSpy'),
    fixedMenu = $('.fixed-menu'),
    activeMenu = $('.active-menu'),
    responMenu = $('.respon-menu'),
    subClick = $('.submenu-click'),
    anchor = $('.anchor'),
    ifAttrDataChild = parentBo.attr('data-child'),
    ifAttrDataNode = nodeBo.attr('data-node'),
    ifClassActiveMenu = activeMenu.hasClass('active-menu'),
    ifClassScrollSpy = scrollSpy.hasClass('scrollSpy'),
    ifClassFixedMenu = fixedMenu.hasClass('fixed-menu'),
    ifClassResponMenu = responMenu.hasClass('respon-menu');

/**
 * [log description]
 * @param  {[type]} p) { console.log(p
 */

window.log = function log(p) { console.log(p) };

/**
 * [win description]
 * @param  {[type]} arg [function]
 * Принимает функцию и запускает ее
 * Перезапускает ее при изменении размера экрана
 */
window.win = function win (arg) {
  var self = arg;
  self();
   $(window).on('resize', function(){ self() });
};

/**
 * Неактивные ссылки
 */
$(document).on('click', '.disabled', function(){ return false })


/**
 * topBody
 */
topBody.on('click', function(e) {
    e.preventDefault();
    htmlBody.animate({scrollTop: 0}, 700)
});

/**
 * Работа с #хэшем в url + history api
 * https://modx.pro/development/520-work-with-the-hash-in-the-url-api-history/
 */

Hash = {
  // Получаем данные из адреса
  get: function() {
    var vars = {}, hash, splitter, hashes;
    if (!this.oldbrowser()) {
      var pos = window.location.href.indexOf('?');
      hashes = (pos != -1) ? decodeURIComponent(window.location.href.substr(pos + 1)) : '';
      splitter = '&';
    }
    else {
      hashes = decodeURIComponent(window.location.hash.substr(1));
      splitter = '/';
    }

    if (hashes.length == 0) {return vars;}
    else {hashes = hashes.split(splitter);}

    for (var i in hashes) {
      if (hashes.hasOwnProperty(i)) {
        hash = hashes[i].split('=');
        if (typeof hash[1] == 'undefined') {
          vars['anchor'] = hash[0];
        }
        else {
          vars[hash[0]] = hash[1];
        }
      }
    }
    return vars;
  }
  // Заменяем данные в адресе на полученный массив
  ,set: function(vars) {
    var hash = '';
    for (var i in vars) {
      if (vars.hasOwnProperty(i)) {
        hash += '&' + i + '=' + vars[i];
      }
    }

    if (!this.oldbrowser()) {
      if (hash.length != 0) {
        hash = '?' + hash.substr(1);
      }
      window.history.pushState(hash, '', document.location.pathname + hash);
    }
    else {
      window.location.hash = hash.substr(1);
    }
  }
  // Добавляем одно значение в адрес
  ,add: function(key, val) {
    var hash = this.get();
    hash[key] = val;
    this.set(hash);
  }
  // Удаляем одно значение из адреса
  ,remove: function(key) {
    var hash = this.get();
    delete hash[key];
    this.set(hash);
  }
  // Очищаем все значения в адресе
  ,clear: function() {
    this.set({});
  }
  // Проверка на поддержку history api браузером
  ,oldbrowser: function() {
    return !(window.history && history.pushState);
  }
};

//===================================================
// Обработка табов

if(anchor.hasClass('anchor')){

var anchorChild = anchor.find('a').addClass('anchor-link');

  $(document).on('click', '.anchor-link', function (e) {
    e.preventDefault();
    var href = $(this).attr('href').substr(1);
    Hash.add('tab', href);
  });

  // Переключение таба при загрузке страницы
  $(window).load(function() {
    var hash = Hash.get();
    if (hash.tab) {
      var linkClick = anchor.find('a[href="#' + hash.tab + '"]');
      if(linkClick.is(":visible")){
        linkClick.trigger('click');
      } else{
        var parentClick = linkClick.closest('ul').parent();
          parentClick.trigger('hover').trigger('click');
          linkClick.trigger('click');
      }  
    } // hash.tab
  }) // $(window).load
} // anchor.hasClass('anchor')

/**
 * Модификация классов
 * data-child, data-node = 'class'
 * data-mod='mod--mod2--mod3'
 * result class-mod, class-mod2, class-mod3
 * default mod ['size','dec','hov','act','dis']
 */
if(ifAttrDataChild || ifAttrDataNode) {

var arrBo = [parentBo,nodeBo];
var boFunc = function(arrBo){
  var dataAttr = function(modBo,valBo,dataBo){
          dataBo = (dataBo.attr('data-child')) ? dataBo.children() : dataBo
          dataBo.addClass(valBo); // add class data-child
          if(modBo) { 

            var arrMod = modBo.split('--');
            $.each(arrMod, function(k, keyMod){
              $.each(arrModClass, function(j, keyCl){
                         if(keyMod == keyCl) {
                          var modClass = valBo + '-' + keyMod;
                          dataBo.addClass(modClass); // add class mod data-child
                          return (keyCl !== keyMod)
                         } 

                         if(j==arrModClass.length-1){
                            if((keyMod !== keyCl)) {
                              dataBo.addClass(keyMod); //add mod class
                            }
                         }
              }) // each arrModClass
            }) // each arrMod
          } // if modBo
        }; // function dataAttr
      $.each(arrBo, function(i,key){
        $.each(key, function(q, kq){
          var valParent = $(kq).attr('data-child');
          var modParent = $(kq).attr('data-mod');

          var valNode = $(kq).attr('data-node');   
          var modNode = modParent;

          if(valParent) dataAttr(modParent,valParent,$(kq));
          if(valNode) dataAttr(modNode,valNode,$(kq));

        }) // each key

        
      }) // each arrBo
   }(arrBo) //  function boFunc 
} // IF ifAttrDataChild || ifAttrDataNode


/**
 * Активный класс меню active-menu
 * add Class active
 */

if(ifClassActiveMenu){
    activeMenu.on('click', 'li', function(e) {
      var self = $(this);
      e.preventDefault();
      // Если нет класса Disable, то добавляем активный класс
      if(!self.hasClass('disabled')) {
        self.siblings().removeClass('active')
        self.addClass('active');
      } 
    })
} // IF ifClassActiveMenu

/**
 * Fixed menu
 * add class fixed-menu 
 */
if(ifClassFixedMenu){
var menuOffset = fixedMenu.offset().top - fixedMenu.height();
$(window).on('scroll', function(){
              scroller = $(window).scrollTop();
              scroller >= menuOffset ? fixedMenu.addClass('fixed') 
                                    : fixedMenu.removeClass('fixed');
  }); // scroll
}

/**
 * [scrollSpy description]
 * add Class scrollSpy
 * 
 */
if(ifClassScrollSpy) {
      var scrollSpyLink = scrollSpy.find('a');
      // Прокрутка при клике
      scrollSpyLink.on('click', function(e) {
        var offset = returnOffset();
        var id = $(this).attr("href");
        if(id.indexOf('#') == '-1'){
          window.location = id;
        }
        var target = $(id).offset().top-offset;
        target = Math.round(target);
        htmlBody.animate({ scrollTop: target }, 500);
        e.preventDefault();
       }); // click scrollSpyLink

      // Активация кнопки
      $(window).on('scroll', function(){
              scroller = $(window).scrollTop(); // узнаем текущий скролл
              var offset = returnOffset(); // получаем из функции высоту елемента
              $.each(scrollSpyLink, function() { // перебираем все ссылки
                var self = $(this);
                var id = self.attr("href"); // узнаем href ссылки
                if(id !== undefined && id.indexOf('#') == 0) {
                    var target = id ? $(id).offset().top-offset : 10e6; // узнаем позицию елемента
                    target = Math.round(target); // округляем ее
                }   
                  if(target < 10e6){
                    self.parent('li').removeClass('active');
                    var targetHeight = $(id).height();
                    var targetEnd = target + targetHeight;
                     if(scroller >= target && scroller < targetEnd) {
                      self.parent('li').addClass('active');
                      // добавляем якорь, при наличии класса anchor-spy 
                        if(anchor.hasClass('anchor-spy')){
                          var href = self.attr('href').substr(1);
                          Hash.add('tab', href);
                        }
                      } // if(scroller >= target && scroller < targetEnd)
                    } // if (target < 10e6)
              }) // each scrollSpyLink    
      }); // scroll

      function returnOffset (argument) {
        var fixClass = fixedMenu.hasClass('fixed');
        var offset = ifClassFixedMenu  ? fixClass 
                                       ? scrollSpy.height() 
                                       : 2*scrollSpy.height() 
                                       : 0; 
                                       return offset;
      }

} // IF ifClassScrollSpy


/**
* respon-menu
*/
if(ifClassResponMenu){
  var heightMenu = responMenu.height();
  function responsiveMenu(minMenu) {
    var wid = $(window).width();
    var minMenu = minMenu || 800;
    if(wid<minMenu){
      responMenu.addClass('mobMenu hideMenu');
      $('.mobMenu').on('click', function() {
          responMenu.toggleClass('hideMenu')
                    .find('li:first').css('margin-top', heightMenu);
      })
    } else {
      responMenu.removeClass('mobMenu hideMenu');
    }
  }
  win(responsiveMenu);


} // ifClassResponMenu

/**
 * Родителю даем класс parent 
 * Дети получают класс child
 */
parent.children().addClass('child');

/**
 * Для вертикального меню
 */
$('.sub-vertical').parent('li').addClass('relative');

/**
 * add class submenu-click
 * Открывается меню при клике
 * При повторном клике прячем - не реализовано
 */
subClick.parent('li').on('click', function(e){
  e.preventDefault()

  var thisLink =  $(this).children('.submenu-click');
  if(thisLink.is(':visible')){
       // thisLink.removeClass('show')
  } else {
    thisLink
    .parents('ul')
    .find('ul')
    .removeClass('show')
    .end().end()
    .removeClass('hide')
    .addClass('show')
  }
    
})

/**
 * При потере фокуса submenu-click скрываем меню
 */
subClick.hover(function(){
},function(){
  subClick.removeClass('show');
})

/**
 * Tabs
 * Paretn add class tabs + tabs-child
 * tabs = data-tabs
 * tabs-child = data-tabs-child
 */

var tabsLink = $('.tabs').find('a');
var tabsChildLink = $('.tabs-child').find('a');
var dataTabs = $('[data-tabs]');
var dataTabsChild = $('[data-tabs-child]');
var dataTabsDef = $('[data-tabs-def]');
var dataTabsChildDef = $('[data-tabs-child-def]');

dataTabs.addClass('hide');

var tabsDef = dataTabsDef.attr('data-tabs-def');
 $('[data-tabs="' + tabsDef +'"]').removeClass('hide')

 function tabsClick(self,tabs,child){
   var child = child || '';
   var thisAttr = self.attr('id');
   tabs.addClass('hide');
   $('[data-tabs' + child + '="' + thisAttr +'"]').removeClass('hide')
 }

tabsLink.on('click', function(){
  tabsClick($(this),dataTabs)
})

tabsChildLink.on('click', function(){
  tabsClick($(this),dataTabsChild,'-child')
})


})(jQuery);